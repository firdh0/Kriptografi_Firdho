result = pow(101, 17, 22663)
print(result)